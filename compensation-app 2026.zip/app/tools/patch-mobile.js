const fs=require('fs');let h=fs.readFileSync('tools/src-index.html','utf8');
h=h.replace('width=device-width,initial-scale=1"',()=>'width=device-width,initial-scale=1,viewport-fit=cover"')
.replace('</style>',()=>`
html{-webkit-text-size-adjust:100%}body{overflow-x:hidden;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)}
.grid>*,.dg>*,.card,#out{min-width:0}#out{display:block}#out>.card,#out>.dg{margin-bottom:16px}
nav{position:sticky;top:0;z-index:5;background:var(--bg)}
@media(max-width:640px){
 header{padding:12px 12px 0}h1{font-size:1.15rem}header p{font-size:.8rem}nav{padding:0 8px}nav button{padding:10px}
 main{padding:10px}.grid,.dg{gap:10px}.card{padding:12px;border-radius:10px}.card h3{font-size:.95rem}
 .big{font-size:1.5rem}.kpis{gap:8px}.kpi{padding:8px;font-size:.78rem}.kpi b{font-size:.98rem;overflow-wrap:anywhere}
 th,td{padding:7px 4px;font-size:.8rem}td:first-child,th:first-child{min-width:104px}
 .hr{grid-template-columns:64px 1fr 50px;gap:6px;font-size:.78rem}.hr .hl{font-size:.78rem}
 .chips{flex-wrap:nowrap;overflow-x:auto;padding-bottom:4px;scrollbar-width:thin}.chips label{flex:none;white-space:nowrap}
 .svg text{font-size:17px}.dn{flex-direction:column;align-items:flex-start}
 .cards{grid-template-columns:1fr}.row{flex-direction:column;gap:0}
 button.go{position:sticky;bottom:8px;z-index:3;box-shadow:0 4px 14px rgba(0,0,0,.25)}
}
@media(max-width:380px){.kpis{grid-template-columns:1fr 1fr}.hr{grid-template-columns:56px 1fr 46px}}
</style>`);
fs.writeFileSync('tools/src-index.html',h);
