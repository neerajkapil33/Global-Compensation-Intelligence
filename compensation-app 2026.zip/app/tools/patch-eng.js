const fs=require('fs'),r=f=>fs.readFileSync(f,'utf8');
let e=r('lib/engine.js');
e=e.replace("contract:'Fixed-term contract employee',",()=>"contract:'Fixed-term contract employee',temporary:'Temporary / seasonal employee',thirdparty:'Third-party / agency staff',")
 .replace("er=sc(r.er),ee=sc(r.ee),pg=r.g*yf,eeT=sm(ee),erT=sm(er),ctcP=ctc*yf;",()=>"er=sc(r.er),ee=sc(r.ee),pg=r.g*yf,eeT=sm(ee),ctcP=ctc*yf,upl=({temporary:.05,thirdparty:.18}[wt]||0)*sm(er);if(upl)er.push([wt==='thirdparty'?'Agency margin (planning assumption: 18% of employer statutory cost)':'Onboarding uplift (planning assumption: 5% of employer statutory cost)',upl]);const erT=sm(er);")
 .replace("totals:{ctc:ctcP,",()=>"totals:{engagerCost:ctcP+upl,ctc:ctcP,")
 .replace("if(non)notes.push('Non-employee",()=>"if(wt==='temporary')notes.push('Temporary or seasonal employees carry the statutory stack; many benefits depend on minimum service. See the Engagement tab.');if(wt==='thirdparty')notes.push('Agency staff are on the agency or employer-of-record payroll. Margin is a planning assumption; get the real rate card. See the Engagement tab for liabilities.');if(non)notes.push('Non-employee")
 .replace('module.exports={',()=>r('tools/eng-guide.txt')+'module.exports={engagement,');
fs.writeFileSync('lib/engine.js',e);
let s=r('server.js');s=s.replace('dashboard:E.dashboard}',()=>'dashboard:E.dashboard,engagement:E.engagement}');fs.writeFileSync('server.js',s);
let b=r('tools/build-single.js');b=b.replace('dashboard:E.dashboard};',()=>'dashboard:E.dashboard,engagement:E.engagement};');fs.writeFileSync('tools/build-single.js',b);
let h=r('tools/src-index.html');
h=h.replace("TABS=['Dashboard','Calculator',",()=>"TABS=['Dashboard','Calculator','Engagement',")
 .replace('<option value="contract">Fixed-term contract</option>',()=>'<option value="contract">Fixed-term contract</option><option value="temporary">Temporary / seasonal</option><option value="thirdparty">Third-party / agency</option>')
 .replace("[r.worker.nonEmployee?'Fee paid':'Employer cost (CTC)',money(c,m.ctc),money(c,t.ctc)],",()=>"[r.worker.nonEmployee?'Fee paid':'Employer cost (CTC)',money(c,m.ctc),money(c,t.ctc)],t.engagerCost>t.ctc+1?['Total cost to you (with uplift)',money(c,t.engagerCost/n),money(c,t.engagerCost)]:null,")
 .replace('Compare(){',()=>r('tools/eng-view.txt')+'Compare(){')
 .replace("if(['Dashboard','Calculator','Coverage']",()=>"if(['Dashboard','Calculator','Coverage']")
 .replace('</style>',()=>`.st-ok{background:var(--acc2)}.st-w{background:transparent;border:1px solid var(--warn);color:var(--warn)}.st-a{background:#dbeafe;color:#1e3a8a}.st-n{background:var(--line);color:var(--mut)}
@media(prefers-color-scheme:dark){.st-a{background:#1e3a5f;color:#bfdbfe}}
.st-c-ok{color:var(--acc);font-weight:700}.st-c-w{color:var(--warn);font-weight:700}.st-c-a{color:#3b82f6;font-weight:700}.st-c-n{color:var(--mut)}#out ul{margin:6px 0;padding-left:20px}#out li{margin:4px 0}
</style>`);
fs.writeFileSync('tools/src-index.html',h);
