const fs=require('fs'),r=f=>fs.readFileSync(f,'utf8');
let e=r('lib/engine.js');e=e.replace(/function dashboard\(p\)\{[\s\S]*?\n\}\nmodule\.exports=\{dashboard,/,()=>r('tools/dash-engine.txt')+'module.exports={dashboard,');fs.writeFileSync('lib/engine.js',e);
let h=r('public/index.html');
h=h.replace(/Dashboard\(\)\{[\s\S]*?\n(?=Calculator\(\)\{)/,()=>r('tools/dash-view.txt')).replace('const V={\n',()=>r('tools/dash-helpers.txt')+'const V={\n')
 .replace('</style>',()=>`.dg{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr))}.dg .card h3{margin-top:0}
.hb{display:grid;gap:6px}.hr{display:grid;grid-template-columns:96px 1fr 62px;gap:8px;align-items:center;font-size:.85rem}.hl{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.hr b{text-align:right;font-variant-numeric:tabular-nums}
.ht{position:relative;height:14px;background:var(--line);border-radius:4px;overflow:hidden;display:block}.ht>i{display:block;height:100%;background:var(--acc)}.ht>i.rg{position:absolute;opacity:.55}.ht>u{position:absolute;top:0;width:3px;height:100%;background:var(--ink)}.ht.st{display:flex}.ht.st>i{flex:none}
.lg{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:.8rem;margin-top:8px}.lg i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:4px}.dn{display:flex;gap:16px;align-items:center}
.svg{width:100%;height:auto}.svg text{fill:var(--mut);font-size:11px}</style>`);
fs.writeFileSync('public/index.html',h);
