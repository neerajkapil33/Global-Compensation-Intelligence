const fs=require('fs');
let e=fs.readFileSync('lib/engine.js','utf8');
e=e.replace('module.exports={',()=>`// Dashboard: FX baseline (from Geo reference) only for markets that have pay bands.
const FX={IN:88.5,US:1,GB:.75,DE:.86,SG:1.3,AE:3.6725,AU:1.52,CA:1.39,FR:.86,JP:150,NL:.86,IE:.86,NZ:1.75,SA:3.75,MY:4.2,BR:5.4,ZA:17.3,MX:18.4};
const REG={US:'NAM',CA:'NAM',MX:'LAC',BR:'LAC',GB:'EUR',DE:'EUR',FR:'EUR',NL:'EUR',IE:'EUR',AE:'ME',SA:'ME',ZA:'AF',IN:'SAS',SG:'EAP',MY:'EAP',JP:'EAP',AU:'OCE',NZ:'OCE'};
function dashboard(p){
  const pick=(v,all)=>{const a=(Array.isArray(v)?v:[]).filter(x=>all.includes(x));return a.length?a:all};
  const roles=pick(p.roles,ROLES),levels=pick(p.levels,LEVELS),region=REG&&Object.values(REG).includes(p.region)?p.region:'ALL';
  const usd=(c,r,l)=>{const b=bandFor(c,r,l);return b?b.med/FX[c]:null};
  const mean=(c,rs,ls)=>{const v=rs.flatMap(r=>ls.map(l=>usd(c,r,l))).filter(x=>x!==null);return v.length?avg(v):null};
  const codes=Object.keys(FX).filter(c=>K[c]&&(region==='ALL'||REG[c]===region));
  const ranked=codes.map(c=>({country:info(c),usd:mean(c,roles,levels),conf:marketBands[c]?'researched':'anchored'})).filter(x=>x.usd!==null).map(x=>({...x,usd:Math.round(x.usd)})).sort((a,b)=>b.usd-a.usd);
  const med=ranked.length?[...ranked].sort((a,b)=>a.usd-b.usd)[ranked.length>>1].usd:0;
  const functions=ROLES.map(r=>({role:r,usd:Math.round(avg(ranked.map(x=>mean(x.country.code,[r],levels)).filter(v=>v!==null)))})).filter(x=>x.usd).sort((a,b)=>b.usd-a.usd);
  const mc=FX[String(p.country).toUpperCase()]?String(p.country).toUpperCase():(ranked[0]&&ranked[0].country.code);
  const matrix=mc?{country:info(mc),roles:ROLES,levels:LEVELS,cells:ROLES.map(r=>LEVELS.map(l=>{const v=usd(mc,r,l);return v===null?null:Math.round(v)}))}:null;
  return{region,roles,levels,ranked,median:med,spread:ranked.length>1?+(ranked[0].usd/ranked[ranked.length-1].usd).toFixed(1):1,functions,matrix,
    note:'USD at reference exchange rates for the '+Object.keys(FX).length+' markets that have pay bands.'};
}
module.exports={dashboard,`);
fs.writeFileSync('lib/engine.js',e);
let s=fs.readFileSync('server.js','utf8');s=s.replace('tax:E.taxProfile}',()=>'tax:E.taxProfile,dashboard:E.dashboard}');fs.writeFileSync('server.js',s);
let h=fs.readFileSync('public/index.html','utf8');
h=h.replace("TABS=['Calculator',",()=>"TABS=['Dashboard','Calculator',").replace("let META,cur='Calculator'",()=>"let META,cur='Dashboard'")
 .replace("if(cur==='Calculator'||cur==='Coverage')",()=>"if(['Dashboard','Calculator','Coverage'].includes(cur))")
 .replace("const V={\n",()=>`const REGL={NAM:'North America',LAC:'Latin America',EUR:'Europe',ME:'Middle East',AF:'Africa',SAS:'South Asia',EAP:'East & Southeast Asia',OCE:'Oceania'},usd=x=>x==null?'–':'$'+Math.round(x).toLocaleString('en-US');
const V={
Dashboard(){const sr=new Set(META.roles),sl=new Set(META.levels);
 shell(\`<label>Region</label><select id="region"><option value="ALL">World</option>\${Object.entries(REGL).map(([k,v])=>\`<option value="\${k}">\${v}</option>\`).join('')}</select>
 <label>Functions</label><div class="chips" id="rc"></div><label>Levels</label><div class="chips" id="lc"></div><label>Heatmap country</label>\${cSel('country',state.country)}<button class="go">Update dashboard</button>\`);
 bind(async()=>{try{const r=await api('dashboard',{country:$('#country').value,region:$('#region').value,roles:[...sr],levels:[...sl]});const mx=Math.max(1,...r.ranked.map(x=>x.usd)),m=r.matrix,cm=m?Math.max(...m.cells.flat().filter(x=>x)):1;
 out(\`<div class="card"><div class="kpis"><div class="kpi">Markets<b>\${r.ranked.length}</b></div><div class="kpi">Median (USD/yr)<b>\${usd(r.median)}</b></div><div class="kpi">Top ÷ bottom<b>\${r.spread}×</b></div><div class="kpi">Top market<b>\${r.ranked[0]?r.ranked[0].country.flag+' '+r.ranked[0].country.code:'–'}</b></div></div>
 <h3>Average median pay by country (USD / year)</h3>\${tbl(['Country','Pay','Basis'],r.ranked.map(x=>[x.country.flag+' '+esc(x.country.name)+\`<div class="bar"><i style="width:\${x.usd/mx*100}%"></i></div>\`,usd(x.usd),x.conf]))}
 <h3>Functions (USD / year)</h3>\${tbl(['Function','Average'],r.functions.map(x=>[esc(x.role),usd(x.usd)]))}
 \${m?\`<h3>Heatmap: \${m.country.flag} \${esc(m.country.name)} (USD median)</h3><div class="wrap"><table><tr><th></th>\${m.levels.map(l=>'<th class="n">'+esc(l)+'</th>').join('')}</tr>\${m.roles.map((ro,i)=>'<tr><td>'+esc(ro)+'</td>'+m.cells[i].map(v=>\`<td class="n" style="background:color-mix(in srgb,var(--acc) \${v?Math.round(v/cm*70):0}%,transparent)">\${usd(v)}</td>\`).join('')+'</tr>').join('')}</table></div>\`:''}
 <p class="mut">\${esc(r.note)}</p></div>\`)}catch(e){bad(e)}});
 const ch=(id,arr,set)=>{$(id).innerHTML=arr.map(x=>\`<label><input type="checkbox" checked value="\${esc(x)}">\${esc(x)}</label>\`).join('');$(id).querySelectorAll('input').forEach(i=>i.onchange=()=>{i.checked?set.add(i.value):set.delete(i.value)})};ch('#rc',META.roles,sr);ch('#lc',META.levels,sl)},
`);
fs.writeFileSync('public/index.html',h);
let b=fs.readFileSync('tools/build-single.js','utf8');b=b.replace('tax:E.taxProfile};',()=>'tax:E.taxProfile,dashboard:E.dashboard};');fs.writeFileSync('tools/build-single.js',b);
