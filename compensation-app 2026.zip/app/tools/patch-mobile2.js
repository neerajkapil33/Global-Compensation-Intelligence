const fs=require('fs');let h=fs.readFileSync('tools/src-index.html','utf8');
h=h.replace(/const shell=\(form,init\)=>\{[^\n]*\n/,()=>"const shell=(form,init)=>{$('#main').innerHTML=`<div class=\"grid\"><details class=\"card flt\" open><summary>Filters and inputs</summary>${form}</details><div id=\"out\">${init||''}</div></div>`};\n");
h=h.replace("const ch=(id,arr,set)=>{$(id).innerHTML",()=>"if(matchMedia('(max-width:640px)').matches)$('.flt').open=false;\n const ch=(id,arr,set)=>{$(id).innerHTML");
h=h.replace('</style>',()=>`.flt>summary{display:none;cursor:pointer;font-weight:600;list-style:none}.flt>summary::-webkit-details-marker{display:none}
@media(max-width:640px){.flt>summary{display:block}.flt>summary::after{content:' ▾';color:var(--mut)}.flt:not([open])>summary::after{content:' ▸'}.flt[open]>summary{margin-bottom:10px}}
</style>`);
fs.writeFileSync('tools/src-index.html',h);
