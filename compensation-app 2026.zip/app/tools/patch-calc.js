const fs=require('fs'),r=f=>fs.readFileSync(f,'utf8');
let e=r('lib/engine.js');e=e.replace(/function calculate\(p\)\{[\s\S]*?\n\}\n(?=function bandFor)/,()=>r('tools/calc-engine.txt'));fs.writeFileSync('lib/engine.js',e);
let h=r('tools/src-index.html');h=h.replace(/Calculator\(\)\{[\s\S]*?\n(?=Compare\(\)\{)/,()=>r('tools/calc-view.txt'));fs.writeFileSync('tools/src-index.html',h);
