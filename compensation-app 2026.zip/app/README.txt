Global Compensation Intelligence
1. Easiest: double-click public/index.html (works offline, no server needed).
2. With backend API: install Node 18+, run "node server.js" in this folder, open http://localhost:3000
